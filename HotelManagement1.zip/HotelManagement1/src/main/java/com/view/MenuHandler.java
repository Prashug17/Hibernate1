package com.view;

import java.util.Scanner;

public class MenuHandler extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}
	
	public void execute() {
		
		String[] menuItems= {
				"Add Customer-1",
				"Update Customer-2",
				"Delete Customer-3",
				"Display Customers-4",
				"Get Customer Details-5",
				"Allocate Room-6",
				"BookingDetails-7",
				"Exit-8"};
		for(int i=0;i<menuItems.length;i++) {
			System.out.println(menuItems[i]);
		}
	}
	public int promptForChoice() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your choice:");
		int choice =scanner.nextInt();
		return choice;
	}
	
	public void handleMenu() {
		while(true) {
			this.execute();
			int choice = this.promptForChoice();
			
			Action action=null;
			
			switch(choice) {
	         case Actions.AddCustomer:
	             action =new AddAction();
	             action.go();
	         break;
	         case Actions.UpdateCustomer:
	             action =new UpdateAction();
	             action.go();
	         break;
	         case Actions.DeleteCustomer:
	             action =new DeleteAction();
	             action.go();
	         break;
	         case Actions.DisplayCustomers:
	             action =new DisplayAction();
	             action.go();
	         break;
	         case Actions.GetCustomerDetails:
	             action =new CustDetailsAction();
	             action.go();
	         break;
	         case Actions.AllocateRoom:
	             action =new AllocateRoomAction();
	             action.go();
	         break;
	         case Actions.BookingDetails:
	             action =new BookingDetailsAction();
	             action.go();
	         break;
	         
	         case Actions.EXIT:System.exit(0);
			}
		}
		
	}
	

	
}


