package com.view;

public class ActionType {
	public static final int Admin=1;
	public static final int Customer=2;
}
