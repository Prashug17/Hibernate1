package com.view;

import java.util.Scanner;

public class MenuHandler2 extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}
	
	public void execute() {
		
		String[] menuItems= {
				"BookingDetails-7",
				};
		for(int i=0;i<menuItems.length;i++) {
			System.out.println(menuItems[i]);
		}
	}
	public int promptForChoice() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your choice:");
		int choice =scanner.nextInt();
		return choice;
	}
	
	public void handleMenu() {
		while(true) {
			this.execute();
			int choice = this.promptForChoice();
			
			Action action=null;
			
			switch(choice) {
	        
	         case Actions.BookingDetails:
	             action =new GetBookingDetails();
	             action.go();
	         break;
	         
	         case Actions.EXIT:System.exit(0);
			}
		}
		
	}
	

	
}


