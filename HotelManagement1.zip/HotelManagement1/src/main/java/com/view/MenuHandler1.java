package com.view;

import java.util.Scanner;

public class MenuHandler1 {
public void execute() {
		
		String[] menuItems= {
				"Admin-1",
				"Customer-2",
				};
		for(int i=0;i<menuItems.length;i++) {
			System.out.println(menuItems[i]);
		}
	}

public int promptForChoice() {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter your choice:");
	int choice =scanner.nextInt();
	return choice;
}

public void handleMenu() {
	while(true) {
		this.execute();
		int choice = this.promptForChoice();
		
		Action action=null;
		
		switch(choice) {
         case ActionType.Admin:
             action =new MenuHandler();
             action.go();
         break;
         case ActionType.Customer:
             action =new MenuHandler();
             action.go();
         break;
		}
	}
}
}
	

