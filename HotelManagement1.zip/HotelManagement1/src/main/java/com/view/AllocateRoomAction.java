package com.view;

import com.controller.AdminController;

public class AllocateRoomAction extends Action {
	@Override
	 public void init() {
		 System.out.println("================================");
		}
	 @Override
		public void execute() {
		 AdminController admin=new AdminController();
		 admin.allocateRoom();
		}
	 

}

