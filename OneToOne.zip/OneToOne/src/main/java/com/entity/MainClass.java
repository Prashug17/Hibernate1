package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Configuration config = new Configuration();
        config.configure();
        SessionFactory sf = config.buildSessionFactory();
        Session session  =sf.openSession();
        Transaction tran = session.beginTransaction();

        City city=new City();
        Country cnt=new Country();
        
        cnt.setCountry_id(91);
        cnt.setCountry_name("India");
        
        city.setCity_id(001);
        city.setCity_name("Mumbai");
        city.setCountry_id(cnt);
        
        session.save(cnt);
        session.save(city);
        tran.commit();
        
	}

}
