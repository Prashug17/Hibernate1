package com.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity

@Table(name="LuxCar02")
public class LaxoriusCar extends Car {

	@Column(name="engine_capacity")
		private int engine_capacity;
	
	@Column(name="luxorius_features")
		private String luxorius_features;
		public int getEngine_capacity() {
			return engine_capacity;
		}
		public void setEngine_capacity(int engine_capacity) {
			this.engine_capacity = engine_capacity;
		}
		public String getLuxorius_features() {
			return luxorius_features;
		}
		public void setLuxorius_features(String luxorius_features) {
			this.luxorius_features = luxorius_features;
		}
		
		
}
