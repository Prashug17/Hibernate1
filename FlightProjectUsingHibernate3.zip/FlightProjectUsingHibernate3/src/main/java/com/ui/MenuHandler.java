package com.ui;

import java.sql.SQLException;
import java.util.Scanner;

public class MenuHandler {
	
	public void display() {
		String[] mainMenu = {
				"1. Admin",
				"2. Customer",
				"0. Exit"
				
			};
		for (int i = 0; i<mainMenu.length; i++){
			System.out.println(mainMenu[i]);
		}
	}
	
	
	public void handleMenu()  {
		while(true) {
			display();
			Scanner menuScanner = new Scanner(System.in);
			System.out.println("Enter Your Choice");
			int choice = menuScanner.nextInt();
			
			switch(choice) {
			
			case 1 : AdminCredential admin = new AdminCredential();
				try {
					admin.credentialCheck();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			break;
				
			case 2: 
				CustomerInterface cust=new CustomerInterface();
				cust.interfaceHandler();
			break;
			
			
			}
		}
	}

}
