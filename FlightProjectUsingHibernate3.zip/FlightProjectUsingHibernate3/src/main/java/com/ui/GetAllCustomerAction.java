package com.ui;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.bean.Customer;
import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.AdminDaoImpl;


public class GetAllCustomerAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Displaying all the Customers");
		System.out.println("----------------------------------");
		
	}

	@Override
	public void execute() {
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl = new AdminDaoImpl();
		
		impl.getAllCustomers(conf); 
		
		
	}

}
