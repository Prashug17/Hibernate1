package com.ui;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Admin;
import com.db.ConnectionManager;


public class AdminCredential {
	
	public  void credentialCheck() throws SQLException {

		Configuration conf=ConnectionManager.createConnection();
		conf.configure();
		 SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();
	     Transaction trans = session.beginTransaction();
	     
	      Scanner scan=new Scanner(System.in);
			System.out.println("enter id");
			int id = scan.nextInt();
			
			System.out.println("enter username");
			String name = scan.next();
			 
			System.out.println("enter password");
			String pass = scan.next();
	     
		 TypedQuery query=session.createQuery("from Admin");
	        List<Admin> list=query.getResultList();
	        Iterator<Admin> itr= list.iterator();
	        while(itr.hasNext()) {
	        	Admin adm=itr.next();
	        	int admin_id=adm.getAdmin_id();
	        	String username=adm.getName();
	        	String password=adm.getPassword();
	        	
	        	if(admin_id == id && username.equals(name)  && password.equals(pass)) {
					AdminInterface admin = new AdminInterface();
					admin.interfaceHandler();
				}
	        	else {
	        		System.out.println("invalid credential");
	        	}
	        }
	}
}
	        
	  
		
		
	


