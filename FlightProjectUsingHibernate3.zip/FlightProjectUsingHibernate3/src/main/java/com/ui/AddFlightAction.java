package com.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.AdminDaoImpl;


public class AddFlightAction extends Action

{
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Flight");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		Flight flt = new Flight();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter flight name");
		flt.setFlight_name(sc.next());
		System.out.println("Enter date in the format dd-MM-yyyy");
		String date1=sc.next();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date udate = null;
		try {
			udate = sdf.parse(date1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long ms=udate.getTime();
		java.sql.Date sdate=new java.sql.Date(ms);
		
		flt.setFlight_date(sdate);
		System.out.println("Enter source");
		flt.setFlight_source(sc.next());
		System.out.println("Enter destination");
		flt.setFlight_destination(sc.next());
		System.out.println("Enter price");
		flt.setFlight_price(sc.nextFloat());
		System.out.println("Enter duration");
		flt.setFlight_duration(sc.nextFloat());
		System.out.println("Enter seat capacity");
		flt.setFlight_capacity(sc.nextInt());
		
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl = new AdminDaoImpl();
		impl.addFlight(conf, flt);
		
	}
}
