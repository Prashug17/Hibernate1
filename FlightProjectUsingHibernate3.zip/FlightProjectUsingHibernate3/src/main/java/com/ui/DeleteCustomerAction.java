package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.db.ConnectionManager;
import com.db.AdminDaoImpl;



public class DeleteCustomerAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Deleting Customer");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Id To Be Deleted");
		int id = sc.nextInt();
		
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl = new AdminDaoImpl();
		
		impl.deleteCustomer(conf, id);
		
	}

}
