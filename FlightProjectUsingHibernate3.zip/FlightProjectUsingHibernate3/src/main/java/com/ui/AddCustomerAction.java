package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.bean.Customer;
import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.AdminDaoImpl;

public class AddCustomerAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Customer");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Customer cst = new Customer();
		Scanner sc = new Scanner(System.in);
	
		
		System.out.println("Enter Customer name");
		cst.setCustomer_name(sc.next());
		System.out.println("Enter username");
		cst.setCustomer_username(sc.next());
		System.out.println("Enter password");
		cst.setCustomer_password(sc.next());
		System.out.println("Enter email");
		cst.setCustomer_email(sc.next());
		System.out.println("Enter Phone number");
		cst.setCustom_phone(sc.next());
		
		
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl = new AdminDaoImpl();
		impl.addCustomer(conf, cst);

	}
}
