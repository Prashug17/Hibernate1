package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.db.ConnectionManager;
import com.db.AdminDaoImpl;


public class UpdateFlightAction extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("updating flight");
		System.out.println("------------------------");
		
	}

	@Override
	public void execute() {
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl=new AdminDaoImpl();
		impl.updateFlight(conf);
		
	}

}
