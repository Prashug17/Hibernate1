package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.db.ConnectionManager;
import com.db.AdminDaoImpl;


public class UpdateCustomerAction extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("updating customer");
		System.out.println("------------------------");
		
	}
	
	@Override
	public void execute() {
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl=new AdminDaoImpl();
		impl.updateCustomer(conf);

}
}
