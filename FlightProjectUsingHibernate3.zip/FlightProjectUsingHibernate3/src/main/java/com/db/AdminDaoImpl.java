package com.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.BookingDetails;
import com.bean.Customer;
import com.bean.Flight;
import com.ui.AdminInterface;
import com.ui.CustomerInterface;



public class AdminDaoImpl{
	static int flitid;
	static float price;
	
	static Configuration conf=ConnectionManager.createConnection();
	static Customer customer=new Customer();
	static Flight flight=new Flight();
	static BookingDetails booking=new BookingDetails();

	
	public void addFlight(Configuration conf, Flight flt) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();
			session.save(flt);
	        tran.commit();
	        System.out.println("Flight Added Successsfully");
	        
	        AdminInterface ad = new AdminInterface();
	        ad.interfaceHandler();	
	}
	public void deleteFlight(Configuration conf, int id) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();
        
        Query q = session.createQuery("delete from Flight where flight_id=:i");
        q.setParameter("i", id);

        q.executeUpdate();
        
        trans.commit();
        
        System.out.println("Flight Deleted Successsfully");
        AdminInterface ad = new AdminInterface();
        ad.interfaceHandler();
		
	}
	public void updateFlight(Configuration conf) {
		 SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();
	     Transaction trans = session.beginTransaction();
	     
	     Scanner sc=new Scanner(System.in);
	     System.out.println("Enter flight id");
			int fid=sc.nextInt();
	     System.out.println("Enter flight name");
			String name=sc.next();
			System.out.println("Enter date in the format dd-MM-yyyy");
			String date1=sc.next();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date udate = null;
			try {
				udate = sdf.parse(date1);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			long ms=udate.getTime();
			java.sql.Date sdate=new java.sql.Date(ms);
			
			System.out.println("Enter source");
			String source=sc.next();
			System.out.println("Enter destination");
			String destination=sc.next();
			System.out.println("Enter price");
			Float price=sc.nextFloat();
			System.out.println("Enter duration");
			Float duration=sc.nextFloat();
			System.out.println("Enter seat capacity");
			int capacity=sc.nextInt();
	     
	     Query q = session.createQuery("update Flight set flight_name=:n, flight_date=:d ,flight_source=:s, flight_destination=:a, flight_price=:p, flight_duration=:v, flight_capacity=:c where flight_id =:b");
	     	q.setParameter("b", fid);
	        q.setParameter("n", name);
	        q.setParameter("d", sdate);
	        q.setParameter("s", source);
	        q.setParameter("a", destination);
	        q.setParameter("p", price);
	        q.setParameter("v", duration);
	        q.setParameter("c", capacity);
	     
	        q.executeUpdate();
	        trans.commit();
	     
	     System.out.println("Flight details Updated Successsfully");
	     AdminInterface ad = new AdminInterface();
	     ad.interfaceHandler();
		
	}
	

	public void addCustomer(Configuration conf, Customer cst) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();
			session.save(cst);
	        tran.commit();
	        System.out.println("customer Added Successsfully");
	        
	        CustomerInterface ad = new CustomerInterface();
	        ad.interfaceHandler();
	}
	
	
	public void deleteCustomer(Configuration conf, int id) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();
        
        Query q = session.createQuery("delete from Customer where customer_id=:i");
        q.setParameter("i", id);

        q.executeUpdate();
        trans.commit();
        
        System.out.println("customer Deleted Successsfully");
        CustomerInterface ad = new CustomerInterface();
        ad.interfaceHandler();
		
	}
	public void updateCustomer(Configuration conf) {
		 SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();
	     Transaction trans = session.beginTransaction();
	     
	     Scanner sc=new Scanner(System.in);
	     System.out.println("Enter Customer id");
			int cid=sc.nextInt();
	     System.out.println("Enter Customer name");
			String name=sc.next();
			System.out.println("Enter username");
			String uname=sc.next();
			System.out.println("Enter password");
			String pass=sc.next();
			System.out.println("Enter email");
			String email=sc.next();
			System.out.println("Enter Phone number");
			String phone=sc.next();
			
	     Query q = session.createQuery("update Customer set customer_name=:n, customer_username=:d ,customer_password=:s, customer_email=:a, custom_phone=:p  where customer_id =:b");
	     q.setParameter("b", cid);
	        q.setParameter("n", name);
	        q.setParameter("d", uname);
	        q.setParameter("s", pass);
	        q.setParameter("a", email);
	        q.setParameter("p", phone);
	     
	        q.executeUpdate();
	        trans.commit();
	     
	     System.out.println("Customer details Updated Successsfully");
	     CustomerInterface ad = new CustomerInterface();
	     ad.interfaceHandler();
		
	}
	
	public void getAllCustomers(Configuration conf) {
		SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();

	     TypedQuery query=session.createQuery("from Customer");
	        List<Customer> list=query.getResultList();
	        Iterator<Customer> itr= list.iterator();
	        while(itr.hasNext()) {
	        	Customer cst=itr.next();
	        	System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
	        	System.out.println("(Id:-)"+cst.getCustomer_id()+"| (Name:-)"+cst.getCustomer_name()+"| (User name:-)"+cst.getCustomer_username()+"| (Email:-)"+cst.getCustomer_email()+"| (Phone.No:-)"+cst.getCustom_phone()+"|");
	        	System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
	        }
	        AdminInterface ad = new AdminInterface();
	        ad.interfaceHandler();
	        
	        Scanner sc = new Scanner(System.in);
			System.out.println("press 0 to go back");
			if(sc.nextInt() == 0) {
				ad.interfaceHandler();
			}
	}
	
	
	public void getAllFlights(Configuration conf) {
		SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();

	     TypedQuery query=session.createQuery("from Flight");
	        List<Flight> list=query.getResultList();
	        Iterator<Flight> itr= list.iterator();
	        while(itr.hasNext()) {
	        	Flight flt=itr.next();
	        	System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
	        	System.out.println("(Id:-)"+flt.getFlight_id()+"| (Name:-)"+flt.getFlight_name()+"| (Date:-)"+flt.getFlight_date()+"| (Source:-)"+flt.getFlight_source()+"| (Destination:-)"+flt.getFlight_destination()+"| (Price:-)"+flt.getFlight_price()+"| (Duration:-)"+flt.getFlight_duration()+"| (Capacity:-)"+flt.getFlight_capacity()+"|");
	        	System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
	        }
	        
	        AdminInterface ad = new AdminInterface();
	        ad.interfaceHandler();
	        Scanner sc = new Scanner(System.in);
			System.out.println("press 0 to go back");
			if(sc.nextInt() == 0) {
				ad.interfaceHandler();
			}	
	}
	
	public void addFlightCustomer(Configuration conf, Flight flt) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();
        
        TypedQuery query=session.createQuery("from Flight where flight_date=:a AND flight_source=:b AND flight_destination=:c");
        query.setParameter("a", flt.getFlight_date());
        query.setParameter("b", flt.getFlight_source());
        query.setParameter("c", flt.getFlight_destination());
        List<Flight> list=query.getResultList();
        Iterator<Flight> itr= list.iterator();
         for(Flight f:list) {
        	 flitid=f.getFlight_id();
        	 price=f.getFlight_price();
        	 
         }
         Scanner scanner=new Scanner(System.in);
			System.out.println("Enter your customer id:");
			int cust_id=scanner.nextInt();
			System.out.println("Enter your seat number:");
			int seat=scanner.nextInt();
			
			BookingDetails booking=new BookingDetails();
			booking.setCustomer_id(cust_id);
			booking.setFlight_id(flitid);
			booking.setBooking_amount(price);
			booking.setSeat_number(seat);
			
			session.save(booking);
			tran.commit();
	        System.out.println("Flight Booked Successsfully");
         
	        CustomerInterface ad = new CustomerInterface();
	        ad.interfaceHandler();	
	}
	

	public void deleteFlightCustomer(Configuration conf, int id) {
		SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();
        
        Query q = session.createQuery("delete from BookingDetails where booking_id=:i");
        q.setParameter("i", id);

        q.executeUpdate();
        trans.commit();
        
        System.out.println("Booking canceled Successsfully");
        CustomerInterface ad = new CustomerInterface();
        ad.interfaceHandler();	
		
	}
	
	public void updateBooking(Configuration conf) {
		 SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();
	     Transaction trans = session.beginTransaction();
	     
	     Scanner sc = new Scanner(System.in);
			System.out.println("enter the flight id to update details");
			int id = sc.nextInt();
			System.out.println("Enter date in the format dd-MM-yyyy");
			String date1=sc.next();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date udate = null;
			try {
				udate = sdf.parse(date1);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			long ms=udate.getTime();
			java.sql.Date sdate=new java.sql.Date(ms);
	     
	     Query q = session.createQuery("update Flight set flight_date=:a where flight_id =:b");
	     q.setParameter("a", sdate);
	     q.setParameter("b", id);
	     
	     q.executeUpdate();
	     trans.commit();
	     
	     System.out.println("Date details Updated Successsfully");
	     CustomerInterface ad = new CustomerInterface();
	     ad.interfaceHandler();
		
	}
	
	public void getBookingDetails(Configuration conf,int id) {
		SessionFactory sf = conf.buildSessionFactory();
	     Session session = sf.openSession();
	     Transaction trans = session.beginTransaction();

	     TypedQuery query=session.createQuery("from BookingDetails where booking_id=:i");
	     query.setParameter("i", id);
	        List<BookingDetails> list=query.getResultList();
	        Iterator<BookingDetails> itr= list.iterator();
	        while(itr.hasNext()) {
	        	BookingDetails book=itr.next();
	        	System.out.println("(Booking Id:-)"+book.getBooking_id()+"| (Customer Id:-)"+book.getCustomer_id()+"| (Flight Id:-)"+book.getBooking_amount()+"| (Amount:-)"+book.getBooking_amount()+"| (Seat.No:-)"+book.getSeat_number());
	        }
	        
	        CustomerInterface ad = new CustomerInterface();
	        ad.interfaceHandler();
	        
	        Scanner sc = new Scanner(System.in);
			System.out.println("press 0 to go back");
			if(sc.nextInt() == 0) {
				ad.interfaceHandler();
			}	
	}
	
}
