package com.dao;

import org.hibernate.cfg.Configuration;

public class HotelDao {
	public static Configuration getCustomerObject() {
		Configuration conf=new Configuration();
		conf.configure();
		return conf;
		
	}
}
