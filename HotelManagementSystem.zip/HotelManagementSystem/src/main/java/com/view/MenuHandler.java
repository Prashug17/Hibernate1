package com.view;

import java.util.Scanner;

public class MenuHandler {

	public void displayMenu() {
		String[] menuItems= {
				"Add Customer-1",
				"Update Customer-2",
				"Delete Customer-3",
				"Display Customers-4",
				"Get Customer Details-5",
				"Allocate Room-6",
				"BookingDetails-7",
				"Exit"};
		for(int i=0;i<menuItems.length;i++) {
			System.out.println((i+1)+"."+menuItems[i]);
		}
	}
	public int promptForChoice() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your choice:");
		int choice =scanner.nextInt();
		return choice;
	}
	
	public void handleMenu() {
		while(true) {
			this.displayMenu();
			int choice = this.promptForChoice();
			
			Action action=null;
			
			switch(choice) {
	         case Actions.AddCustomer://System.out.println("option1");
	             action =new AddAction();
	             action.go();
	         break;
	         case Actions.UpdateCustomer://System.out.println("option2");
	             action =new UpdateAction();
	             action.go();
	         break;
	         case Actions.DeleteCustomer://System.out.println("option3");
	             action =new DeleteAction();
	             action.go();
	         break;
	         case Actions.DisplayCustomers://System.out.println("option4");
	             action =new DisplayAction();
	             action.go();
	         break;
	         case Actions.GetCustomerDetails://System.out.println("option4");
	             action =new CustDetailsAction();
	             action.go();
	         break;
	         case Actions.AllocateRoom://System.out.println("option4");
	             action =new AllocateRoomAction();
	             action.go();
	         break;
	         case Actions.BookingDetails://System.out.println("option4");
	             action =new BookingDetailsAction();
	             action.go();
	         break;
	         
	         case Actions.EXIT:System.exit(0);
			}
		}
	}
}
