package com.view;

public class Main {

	public static void main(String[] args) {
		MenuHandler handler=new MenuHandler();
		handler.handleMenu();

	}

}
