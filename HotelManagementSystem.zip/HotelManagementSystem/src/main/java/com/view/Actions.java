package com.view;

public class Actions {
	public static final int AddCustomer=1;
	public static final int UpdateCustomer=2;
	public static final int DeleteCustomer=3;
	public static final int DisplayCustomers=4;
	public static final int GetCustomerDetails=5;
	public static final int AllocateRoom=6;
	public static final int BookingDetails=7;
	public static final int EXIT=8;
}
