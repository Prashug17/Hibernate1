package com.view;

import com.controller.AdminController;

public class MainClass {

	public static void main(String[] args) {
		AdminController con=new AdminController();
		con.addCustomer();
		//con.updateCustomer();
		//con.deleteCustomer();
		//con.displayCustomers();
		//con.getCustomerDetails();
		//con.allocateRoom();
		//con.bookingDetails();
	}

}
