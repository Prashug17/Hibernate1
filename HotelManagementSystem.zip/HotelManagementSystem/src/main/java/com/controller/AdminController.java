package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dao.HotelDao;
import com.entity.BookingDetails;
import com.entity.Customer;
import com.entity.Room;

public class AdminController {
//We will create 4 methods here
	
	static Configuration conf=HotelDao.getCustomerObject();
	static Customer cust=new Customer();
	static Room room=new Room();
	static BookingDetails booking=new BookingDetails();
	
	public static void addCustomer() {
        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

        System.out.println("enter your ID");
        int Id = input.nextInt();

        System.out.println("enter your name");
        String Name = input.next();

        System.out.println("enter your gender");
        String Gender = input.next();
        
        System.out.println("enter your age");
       int Age = input.nextInt();
        
        System.out.println("enter your Address");
        String Address = input.next();
        
        System.out.println("enter your Phone");
        String Phone = input.next();
        
        System.out.println("enter your Email");
        String Email = input.next();
        
        cust.setName(Name);
        cust.setGender(Gender);
        cust.setAge(Age);
        cust.setAddress(Address);
        cust.setPhone(Phone);
        cust.setEmail(Email);
        
        session.save(cust);
        tran.commit();
        System.out.println("customer Added Successsfully");
    }

 
	public static void updateCustomer() {

		 

        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

 

        System.out.println("enter id to update:");
        int Id = input.nextInt();

 

        System.out.println("enter new name:");
        String Name = input.next();
        
        System.out.println("enter new gender:");
        String Gender = input.next();
        
        System.out.println("enter new age:");
        int Age = input.nextInt();
        
        System.out.println("enter new address:");
        String Address = input.next();
        
        System.out.println("enter new phone:");
        String Phone = input.next();
        
        System.out.println("enter new Email:");
        String Email = input.next();

 

        // update Customer set cust_name=:n where cust_id=1;;
        Query q = session.createQuery("update Customer set Name=:n, Gender=:g ,Age=:a, Address=:b, Phone=:p, Email=:e where Id=:i");
       
        q.setParameter("i", Id);
        q.setParameter("n", Name);
        q.setParameter("g", Gender);
        q.setParameter("a", Age);
        q.setParameter("b", Address);
        q.setParameter("p", Phone);
        q.setParameter("e", Email);

 

        int status = q.executeUpdate();
        System.out.println(status + "rows updated");
        trans.commit();

 

    }
	
	
	public static void deleteCustomer() {

		 

        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

 

        System.out.println("enter id to delete:");
        int Id = input.nextInt();

 

        // update Customer set cust_name=:n where cust_id=1;;
        Query q = session.createQuery("delete from Customer where Id=:i");
        q.setParameter("i", Id);

 

        int status = q.executeUpdate();
        System.out.println(status + "rows updated");
        trans.commit();

 

    }
	
	public static void displayCustomers() {
		SessionFactory sf=conf.buildSessionFactory();
        Session session =sf.openSession();
        //select*from customer
        
        TypedQuery query=session.createQuery("from Customer");
        List<Customer> list=query.getResultList();
        Iterator<Customer> itr= list.iterator();
        while(itr.hasNext()) {
        	Customer cst=itr.next();
        	System.out.println("(Id:-)"+cst.getId()+"   (Name:-)"+cst.getName()+"   (Gender:-)"+cst.getGender()+"    (Age:-)"+cst.getAge()+"   (Address:-)"+cst.getAddress()+"   (Phone:-)"+cst.getPhone()+"    (Email:-)"+cst.getEmail());
        }
	}

	public static void getCustomerDetails() {

		 

        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction trans = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

 

        System.out.println("enter id to Search:");
        int Id = input.nextInt();

 

        // update Customer set cust_name=:n where cust_id=1;;


        
        TypedQuery query=session.createQuery("from Customer where Id=:i");
        query.setParameter("i", Id);
        List<Customer> list=query.getResultList();
        Iterator<Customer> itr= list.iterator();
         for(Customer c:list) {
        	 System.out.println(c);
         }

 

        
        trans.commit();
        

    }
	
	public static void allocateRoom() {
        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

        System.out.println("enter room number");
        int room_Number = input.nextInt();

        System.out.println("enter room type");
        String room_Type = input.next();

        System.out.println("enter room fare");
        int room_Fare = input.nextInt();
        
        System.out.println("AC availability");
        Boolean ac_Available = input.nextBoolean();
        
        System.out.println("Room availability");
        Boolean room_Available = input.nextBoolean();
        
        
        room.setRoom_Number(room_Number);
        room.setRoom_Type(room_Type);
        room.setRoom_Fare(room_Fare);
        room.setAc_Available(ac_Available);
        room.setRoom_Available(room_Available);
        
        
        session.save(room);
        tran.commit();
        System.out.println("Room details added successsfully");
    }

	public static void bookingDetails() {
        SessionFactory sf = conf.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tran = session.beginTransaction();

 

        Scanner input = new Scanner(System.in);

        System.out.println("enter ID");
        int id = input.nextInt();

        System.out.println("enter date");
        String date = input.next();

        System.out.println("enter name");
        String name1 = input.next();
        
        System.out.println("enter phone number");
        String PhoneNumber = input.next();
        
        System.out.println("enter date of hire");
        String DayToHireFor = input.next();
        
        System.out.println("enter fare");
        Float Fare = input.nextFloat();
        
        System.out.println("enter bill");
        Float Bill = input.nextFloat();
        
        
        
        booking.setId(id);
        booking.setDate(date);
        booking.setName1(name1);
        booking.setPhoneNumber(PhoneNumber);
        booking.setDayToHireFor(DayToHireFor);
        booking.setFare(Fare);
        booking.setBill(Bill);
        
        
        
        session.save(booking);
        tran.commit();
        System.out.println("Booking details added successsfully");
    }
	
}

         
         
        
         
 

