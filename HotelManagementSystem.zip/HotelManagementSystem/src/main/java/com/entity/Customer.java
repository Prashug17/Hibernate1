package com.entity;

public class Customer {
	private int Id;
	private String Name;
	private String Gender;
	private int Age;
	private String Address;
	private String Phone;
	private String Email;
	
	
	
	@Override
	public String toString() {
		return "Customer [Id=" + Id + ", Name=" + Name + ", Gender=" + Gender + ", Age=" + Age + ", Address=" + Address
				+ ", Phone=" + Phone + ", Email=" + Email + "]";
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	
}
