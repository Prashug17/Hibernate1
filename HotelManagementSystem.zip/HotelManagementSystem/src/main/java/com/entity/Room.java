package com.entity;

public class Room {
	private int room_Number;
	private String room_Type;
	private int room_Fare;
	private Boolean  ac_Available;
	private Boolean room_Available;
	
	
	public int getRoom_Number() {
		return room_Number;
	}
	public void setRoom_Number(int room_Number) {
		this.room_Number = room_Number;
	}
	public String getRoom_Type() {
		return room_Type;
	}
	public void setRoom_Type(String room_Type) {
		this.room_Type = room_Type;
	}
	public int getRoom_Fare() {
		return room_Fare;
	}
	public void setRoom_Fare(int room_Fare) {
		this.room_Fare = room_Fare;
	}
	public Boolean getAc_Available() {
		return ac_Available;
	}
	public void setAc_Available(Boolean ac_Available) {
		this.ac_Available = ac_Available;
	}
	public Boolean getRoom_Available() {
		return room_Available;
	}
	public void setRoom_Available(Boolean room_Available) {
		this.room_Available = room_Available;
	}
	
	

}
