package com.entity;

public class BookingDetails {
	private int id;
	private String date;
	private String name1;
	private String PhoneNumber;
	private String DayToHireFor;
	private float Fare;
	private float Bill;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getDayToHireFor() {
		return DayToHireFor;
	}
	public void setDayToHireFor(String dayToHireFor) {
		DayToHireFor = dayToHireFor;
	}
	public float getFare() {
		return Fare;
	}
	public void setFare(float fare) {
		Fare = fare;
	}
	public float getBill() {
		return Bill;
	}
	public void setBill(float bill) {
		Bill = bill;
	}
	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", date=" + date + ", name1=" + name1 + ", PhoneNumber=" + PhoneNumber
				+ ", DayToHireFor=" + DayToHireFor + ", Fare=" + Fare + ", Bill=" + Bill + "]";
	}
	
	
	
	
}
