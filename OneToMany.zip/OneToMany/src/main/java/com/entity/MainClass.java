package com.entity;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Configuration config = new Configuration();
        config.configure();
        SessionFactory sf = config.buildSessionFactory();
        Session session=new Configuration().configure().buildSessionFactory().openSession();
        Criteria crt=session.createCriteria(City.class);
        List<City>cityList=crt.list();

        for(City city:cityList) {
            System.out.println(city.getCity_name());
        }
        
        
        
//        Session session  =sf.openSession();
//        Transaction tran = session.beginTransaction();
//
//        City city1=new City();
//        City city2=new City();
//        Country cnt=new Country();
//        
//        cnt.setCountry_id(91);
//        cnt.setCountry_name("India");
//        
//        city1.setCity_id(001);
//        city1.setCity_name("Mumbai");
//        city1.setCountry_id(cnt);
//        
//        city2.setCity_id(002);
//        city2.setCity_name("Bangalore");
//        city2.setCountry_id(cnt);
//        
//        List<City> cityList=new ArrayList<City>();
//        cityList.add(city1);
//        cityList.add(city2);
//        
//        cnt.setCityList(cityList);
        
    
        
//        session.save(cnt);
//        session.save(city1);
//        session.save(city2);
//        tran.commit();
        
//        City getCity=session.get(City.class,new Integer(2));
//        System.out.println("City ID="+getCity.getCity_id());
//        System.out.println("City ID="+getCity.getCity_name());
        
	}

}
