package com.driver;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entities.Car;
import com.entities.EconomicalCar;
import com.entities.LaxoriusCar;

public class MainClass {

	public static void main(String[] args) {
		Car car=new Car();
		EconomicalCar ecoCar=new EconomicalCar();
		LaxoriusCar luxCar= new LaxoriusCar();
		
		car.setCar_name("MARUTHI");

        ecoCar.setCar_name("ALTO NEW");
        ecoCar.setCar_price(4.5f);
        ecoCar.setCar_milage(22);

        luxCar.setCar_name("audi car");
        luxCar.setEngine_capacity(18);
        luxCar.setLuxorius_features("ALL");

        Configuration config = new Configuration();
        config.configure();
        SessionFactory sf = config.buildSessionFactory();
        Session session  =sf.openSession();
        Transaction tran = session.beginTransaction();

        session.save(car);
        session.save(ecoCar);
        session.save(luxCar);
        tran.commit();

	}

}
