package com.entities;


public class LaxoriusCar extends Car {

		private int engine_capacity;
		private String luxorius_features;
		public int getEngine_capacity() {
			return engine_capacity;
		}
		public void setEngine_capacity(int engine_capacity) {
			this.engine_capacity = engine_capacity;
		}
		public String getLuxorius_features() {
			return luxorius_features;
		}
		public void setLuxorius_features(String luxorius_features) {
			this.luxorius_features = luxorius_features;
		}
		
		
}
