package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.db.ConnectionManager;

public class CustomerInterface {
	public void display() {
		String[] mainMenu = { "1. Register ", "3. Update Datails", "4. Delete Account ",
				"5. Book Ticket", "6. Cancel Ticket ", "7. Update Ticket Datails", "8. Get Booking Details", "0. Exit" };
		for (int i = 0; i < mainMenu.length; i++) {
			System.out.println(mainMenu[i]);
		}

	}

	public int choice() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Choice");
		int choice = sc.nextInt();
		return choice;
	}

	public void interfaceHandler() {
		Configuration conf=ConnectionManager.createConnection();
		conf.configure();
		while (true) {
			display();
			int choice = this.choice();
			switch (choice) {
			
			case 1:
				Action act1 = new AddCustomerAction();
				while (true) {
					act1.init();
					act1.execute();
				}

			case 2:
				Action act2 = new UpdateCustomerAction();
				while (true) {
					act2.init();
					act2.execute();
				}

			case 3:
				Action act3 = new UpdateCustomerAction();
				while (true) {
					act3.init();
					act3.execute();
				}

			case 4:
				Action act4 = new DeleteCustomerAction();
				while (true) {
					act4.init();
					act4.execute();

				}

			case 5:
				Action act5 = new AddFlightActionCustomer();
				while (true) {
					act5.init();
					act5.execute();
				}

			case 6:
				Action act6 = new DeleteFlightActionCustomer();
				while (true) {
					act6.init();
					act6.execute();
				}

			case 7:
				Action act7 = new UpdateFlightActionCustomer();
				while (true) {
					act7.init();
					act7.execute();
				}

			case 8:
				Action act8 = new GetBookingDetailsAction();
				while (true) {
					act8.init();
					act8.execute();

				}
			
			case 0:
				MenuHandler menu=new MenuHandler();
				menu.handleMenu();

			default:
				System.out.println("Invalid Choice");

			}
		}
	}
}
