package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import org.hibernate.cfg.Configuration;

import com.db.ConnectionManager;
import com.db.AdminDaoImpl;


public class DeleteFlightActionCustomer extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Cancelling ticket booking");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Booking Id to cancel booking");
		int id = sc.nextInt();
		
		Configuration conf=ConnectionManager.createConnection();
		AdminDaoImpl impl = new AdminDaoImpl();
		
		impl.deleteFlightCustomer(conf, id);
	}

}
