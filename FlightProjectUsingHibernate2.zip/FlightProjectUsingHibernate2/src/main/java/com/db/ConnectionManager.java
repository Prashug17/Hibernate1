package com.db;

import org.hibernate.cfg.Configuration;

 

public class ConnectionManager {

    public static Configuration createConnection() {
        try {
        	Configuration conf=new Configuration();
    		conf.configure();
    		return conf;
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }	
}
